import React from 'react'

export const ClaimsPage: React.FC = () => {
    return (
        <section id="faqs" className="bg-[#F5F3EF] py-10 sm:py-14">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col lg:flex-row lg:justify-between items-start gap-8 lg:gap-0">
                <div className="max-w-full lg:max-w-150">
                    <p className="text-sm font-semibold uppercase tracking-wider text-[#D11F3E] mb-2">
                        CLAIMS
                    </p>
                    <h2 className="text-[26px] sm:text-[32px] lg:text-[36px] font-bold text-black leading-[100%] mb-4">
                        File a Claim
                    </h2>
                    <p className="text-[14px] text-gray-600 mb-8 sm:mb-10">
                        We believe claims should be settled fast and fairly. Our digital process
                        ensures you're never left waiting.
                    </p>
                    <div className="relative">
                        <div className="absolute left-3.5 top-0 bottom-0 w-px bg-gray-300"></div>
                        <div className="space-y-6 sm:space-y-8">
                            <Step
                                number="01"
                                title="Report the Incident"
                                description="Notify us online, via app or call our 24/7 hotline within 48 hours"
                            />
                            <Step
                                number="02"
                                title="Submit Documentation"
                                description="Upload photos, receipts or reports through our secure portal."
                            />
                            <Step
                                number="03"
                                title="Track in Real Time"
                                description="Follow your claim status in real time via app or SMS updates."
                            />
                            <Step
                                number="04"
                                title="Receive Your Payout"
                                description="Approved claims paid within 5 days to M-Pesa or bank account."
                            />

                        </div>
                    </div>
                </div>
                <div className="w-full lg:w-122.25 h-auto lg:h-84.25 rounded-[20px] border border-[#B7B7B9] bg-white/10 p-6 sm:p-8 mt-4 lg:mt-16 flex flex-col">

                    <h3 className="text-[24px] sm:text-[28px] lg:text-[32px] font-semibold mb-3 text-black">
                        Ready to file your claims?
                    </h3>
                    <p className="text-[14px] text-gray-600 mb-6">
                        Our team is at hand to guide you through every step from submission to payout
                    </p>
                    <div className="flex items-center gap-2 mb-2 border border-gray-300 text-gray-600 text-[15px] px-4 sm:px-5 py-2 rounded-lg w-fit max-w-full">
                        <span className="w-2 h-2 bg-green-500 rounded-full shrink-0"></span>
                        <p className="text-[14px] sm:text-[15px] text-gray-600">
                            Live support available now
                        </p>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:justify-between gap-3 mt-6 lg:mt-auto mb-0">
                        <button className="bg-[#D11F3E] text-white text-[14px] sm:text-[15px] px-5 py-2.5 sm:py-2 rounded-lg">
                            Start Online Claim
                        </button>
                        <button className="border border-gray-300 text-gray-600 text-[14px] sm:text-[15px] px-5 py-2.5 sm:py-2 rounded-lg">
                            Call Claims Team
                        </button>
                    </div>
                </div>
            </div>
        </section>
    )
}

const Step = ({
    number,
    title,
    description,
}: {
    number: string
    title: string
    description: string
}) => {
    return (
        <div className="flex gap-4 relative">
            <div className="z-10 flex items-center justify-center w-7.5 h-7.5 rounded-full border border-[#D11F3E] text-[10px] text-[#D11F3E] bg-white">
                {number}
            </div>
            <div>
                <h4 className="text-[15px] font-semibold text-black">
                    {title}
                </h4>
                <p className="text-[13px] text-gray-600">
                    {description}
                </p>
            </div>
        </div>
    )
}